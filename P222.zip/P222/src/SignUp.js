import './SignUp.css';
function SignUp(){
    return(
        <div className='signup'>
            <h1 className='h'>Sign Up</h1>

            Name:<input type='text' placeholder='Name'/>
            Email:<input type='email' placeholder='Email'/>
            Password:<input type='password' placeholder='Password'/>
            <button>Register</button>
        </div>
    )
}
export default SignUp;