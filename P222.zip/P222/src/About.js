import "./About.css";
function About(){
   const products = [
  {
    pid: 1,
    pname: "Wireless Mouse",
    price: 799,
    imglink: "images/mouse.jpg",
    description: "Ergonomic wireless mouse with smooth tracking"
  },
  {
    pid: 2,
    pname: "Mechanical Keyboard",
    price: 2499,
    imglink: "images/keyboard.jpg",
    description: "RGB mechanical keyboard with blue switches"
  },
  {
    pid: 3,
    pname: "USB-C Charger",
    price: 1299,
    imglink: "images/charger.jpg",
    description: "Fast charging USB-C power adapter"
  },
  {
    pid: 4,
    pname: "Bluetooth Headphones",
    price: 3499,
    imglink: "images/headphones.jpg",
    description: "Noise cancelling over-ear bluetooth headphones"
  },
  {
    pid: 5,
    pname: "Smart Watch",
    price: 5999,
    imglink: "images/smartwatch.jpg",
    description: "Fitness tracking smartwatch with heart rate monitor"
  },
  {
    pid: 6,
    pname: "Laptop Stand",
    price: 1499,
    imglink: "images/laptop-stand.jpg",
    description: "Adjustable aluminum laptop stand"
  },
  {
    pid: 7,
    pname: "Webcam",
    price: 2299,
    imglink: "images/webcam.jpg",
    description: "Full HD webcam for video conferencing"
  },
  {
    pid: 8,
    pname: "External Hard Drive",
    price: 4999,
    imglink: "images/harddrive.jpg",
    description: "1TB portable external hard drive"
  },
  {
    pid: 9,
    pname: "Pen Drive",
    price: 699,
    imglink: "images/pendrive.jpg",
    description: "64GB USB 3.0 pen drive"
  },
  {
    pid: 10,
    pname: "Bluetooth Speaker",
    price: 1999,
    imglink: "images/speaker.jpg",
    description: "Portable bluetooth speaker with deep bass"
  },
  {
    pid: 11,
    pname: "Gaming Mouse Pad",
    price: 499,
    imglink: "images/mousepad.jpg",
    description: "Large gaming mouse pad with anti-slip base"
  },
  {
    pid: 12,
    pname: "Power Bank",
    price: 1799,
    imglink: "images/powerbank.jpg",
    description: "10000mAh fast charging power bank"
  },
  {
    pid: 13,
    pname: "Wireless Earbuds",
    price: 2999,
    imglink: "images/earbuds.jpg",
    description: "True wireless earbuds with charging case"
  },
  {
    pid: 14,
    pname: "Monitor",
    price: 11999,
    imglink: "images/monitor.jpg",
    description: "24-inch Full HD LED monitor"
  },
  {
    pid: 15,
    pname: "Graphics Tablet",
    price: 4599,
    imglink: "images/tablet.jpg",
    description: "Drawing tablet for designers and artists"
  },
  {
    pid: 16,
    pname: "Router",
    price: 2699,
    imglink: "images/router.jpg",
    description: "Dual band WiFi router for home use"
  },
  {
    pid: 17,
    pname: "Smart Bulb",
    price: 899,
    imglink: "images/bulb.jpg",
    description: "WiFi enabled smart LED bulb"
  },
  {
    pid: 18,
    pname: "Tripod Stand",
    price: 1299,
    imglink: "images/tripod.jpg",
    description: "Flexible tripod stand for mobile and camera"
  },
  {
    pid: 19,
    pname: "Microphone",
    price: 3499,
    imglink: "images/microphone.jpg",
    description: "USB condenser microphone for recording"
  },
  {
    pid: 20,
    pname: "VR Headset",
    price: 3999,
    imglink: "images/vr.jpg",
    description: "Virtual reality headset for immersive gaming"
  }
];
     return(
        <div>
            <h1>Hello from About</h1>
            <div>
                {products.map((pro)=>{
                    return(
                    <div className="card">
                        <img src={pro.imglink} className="i"/>
                        <h2>{pro.pname}</h2>
                        <p>{pro.description}</p>
                        <h3>{pro.price}</h3>
                    </div>
                    )

                })}
            </div>
        </div>
     )
}
export default About;