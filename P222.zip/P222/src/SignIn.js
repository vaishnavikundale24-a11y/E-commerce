import './SignIn.css';
function SignIn(){
    return(
        <div className='signin'>
            <h1 className='h'>Sign In</h1>
            Username:<input type='text' placeholder='Username'/>
            Password:<input type='password' placeholder='Password'/>
        </div>
    )
}
    
    
    
export default SignIn;