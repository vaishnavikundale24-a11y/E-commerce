
import SignIn from "./SignIn";
import SignUp from './SignUp'; 
//import React, {useState} from "react";
//import One from "./One";
import './App.css';
//import './Signin.css';
//import './Signup.css';


function App() {
 
  return (
    <div style={{display:'flex',flexDirection:'column' ,gap:'30px',width:'300px', margin:'40px auto'}}>
     <SignIn/>
     <SignUp/>
    </div>
  );
}

export default App;
