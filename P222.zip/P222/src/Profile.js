function Profile() {
    const employee=[
        {
            imglink:'',
            eName:'Rohit',
            description:"abcd",
            experience: 2
            

        },

        {
            imglink:'',
            eName:'Swaranjali',
            description:"abcd",
            experience: 2
            

        },

        {
            imglink:'',
            eName:'Neha',
            description:"abcd",
            experience: 2
            

        },

        {
            imglink:'',
            eName:'Raj',
            description:"abcd",
            experience: 2
            

        },

        {
            imglink:'',
            eName:'Adhira',
            description:"abcd",
            experience: 2
            

        },

        {
            imglink:'',
            eName:'Shruti',
            description:"abcd",
            experience: 2
            

        },
    ];
    return(
        <div>
            <h1>Hello From Profile</h1>
            <div>
               {employee.map((emp)=>{return(
                <div className="card">
                <img src={emp.imglink} className="i"/>
                <h1>{emp.eName}</h1>
                <h2>{emp.experience}</h2>
                <p>{emp.description}</p>
                </div>
               )
               })}
            </div>
        </div>
       
    )
    
}
export default Profile;