import { useState } from "react";

function One() {
    var [name, setName] = useState("Vaishnavi");
    var [num, setNum] = useState(10);
    var [yes, setNo] = useState("False");
    var [double, setDouble] = useState(2);
    var [col, setCol] = useState("Yellow");
    
    var change = () => {
        setName = "Swara";
    }
    var chnage2 = () => {
        setNum(num + 10);
    }
    var chnage3 = () => {
        setNo("True");
    }
    var change4 = () => {
        setDouble(double * 2);
    }
    var Change5 = () => {
        setCol("Blue");
    }
    

        return (
            <div>
                <h1>Hello from One {name}</h1>
                <button onClick={change}>Change</button>
                <h1>{num}</h1>
                <button onClick={chnage2}>Change number</button>
                <h1>{yes}</h1>
                <button onClick={chnage3}>change boolean</button>
                <h1>{double}</h1>
                <button onClick={change4}>Change number by 2</button>
                <h1>Welcome</h1>
                <div style={{ height: "200px", background: col, width: "200px" }}></div>
                <button onClick={Change5}>change color</button>
            </div>
        )
    }

    export default One;